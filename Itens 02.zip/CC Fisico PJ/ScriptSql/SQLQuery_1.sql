IF(OBJECT_ID('TB_FISICA_CONTA_EPS') IS NULL)
BEGIN
    CREATE TABLE TB_FISICA_CONTA_EPS 
    (
         ID            INT           IDENTITY(1,1)  
        ,EPS_Nome      VARCHAR (100) NOT NULL  
        ,CadastradoEm  DATETIME      NOT NULL  
        ,CadastradoPor VARCHAR (200)  
        ,AlteradoEm    DATETIME  
        ,AlteradoPor   VARCHAR (200) 
    );

    ALTER TABLE TB_FISICA_CONTA_EPS ADD CONSTRAINT TB_FisicaContaEPS_PK PRIMARY KEY CLUSTERED (ID);
END
ELSE
BEGIN 
    PRINT('Tabela TB_FISICA_CONTA_EPS já criada anteriormente.')
END 


IF(OBJECT_ID('TB_Onboarding_Automacao_EPS') IS NULL)
BEGIN
    CREATE TABLE TB_Onboarding_Automacao_EPS 
    (
      ID             INT IDENTITY(1,1)  
     ,ID_Automacao   INT NOT NULL  
     ,ID_EPS         INT NOT NULL  
     ,DacCPF_Inicio  VARCHAR (2) NOT NULL  
     ,DacCPF_Fim     VARCHAR (2) NOT NULL  
     ,DataCadastro   DATETIME NOT NULL CONSTRAINT OnboardingAutomacaoEPS_DF_DataCadastro DEFAULT GETDATE() 
     ,Ativo          BIT      NOT NULL CONSTRAINT OnboardingAutomacaoEPS_DF_Ativo DEFAULT 1  
     ,Cadastrado_Por VARCHAR (600)  
     ,Alterado_Por   VARCHAR (600) 
    );
    ALTER TABLE TB_Onboarding_Automacao_EPS ADD CONSTRAINT OnboardingAutomacaoEPS_PK PRIMARY KEY CLUSTERED (ID);
END 
ELSE
BEGIN 
    PRINT('Tabela TB_FISICA_CONTA_EPS já criada anteriormente.')
END 



IF(OBJECT_ID('TB_Onboarding_Automacoes') IS NULL)
BEGIN
    CREATE TABLE TB_Onboarding_Automacoes 
        (
         ID             INT           IDENTITY(1,1)
        ,ID_RAAS        INT           NOT NULL  
        ,Titulo         VARCHAR (400) NOT NULL  
        ,Nome           VARCHAR (400) NOT NULL  
        ,DataCadastro   DATETIME      NOT NULL CONSTRAINT OnboardingAutomacoes_DF_DataCadastro DEFAULT GETDATE()  
        ,Ativo          BIT           NOT NULL CONSTRAINT OnboardingAutomacoes_DF_Ativo        DEFAULT 1  
        ,Cadastrado_Por VARCHAR (600)  
        ,Alterado_Por   VARCHAR (600) 
        );
        ALTER TABLE TB_Onboarding_Automacoes ADD CONSTRAINT OnboardingAutomacoes_PK PRIMARY KEY CLUSTERED (ID);
END
BEGIN 
    PRINT('Tabela TB_Onboarding_Automacoes já criada anteriormente.');
END 

IF(OBJECT_ID('TB_Onboarding_Segmentos_Envio') IS NULL)
BEGIN

    CREATE TABLE TB_Onboarding_Segmentos_Envio 
    (
      ID              INT IDENTITY(1,1)  
     ,ID_AutomacaoEPS INT NOT NULL  
     ,ID_Segmento     INT NOT NULL  
     ,DataCadastro    DATETIME NOT NULL CONSTRAINT OnboardingSegmentosEnvio_DF_DataCadastro DEFAULT (GETDATE())
     ,Ativo           BIT      NOT NULL CONSTRAINT OnboardingSegmentosEnvio_DF_Ativo        DEFAULT (1)
     ,Cadastrado_Por  VARCHAR (600) NOT NULL  
     ,Alterado_Por    VARCHAR (600) 
    )
    ALTER TABLE TB_Onboarding_Segmentos_Envio ADD CONSTRAINT OnboardingSegmentosEnvio_PK PRIMARY KEY CLUSTERED (ID)
END 


IF(OBJECT_ID('TB_OnboardingAutomacoes_Segmentos') IS NULL)
BEGIN
    CREATE TABLE TB_OnboardingAutomacoes_Segmentos 
    (
      ID             INT IDENTITY(1,1)    
     ,Segmento       VARCHAR (300)  
     ,DataCadastro   DATETIME NOT NULL CONSTRAINT OnboardingAutomacoesSegmentos_DF_DataCadastro DEFAULT GETDATE()  
     ,Ativo          BIT DEFAULT 1  
     ,Cadastrado_Por VARCHAR (600) NOT NULL 
    )
    ALTER TABLE TB_OnboardingAutomacoes_Segmentos ADD CONSTRAINT OnboardingAutomacoesSegmentos_PK PRIMARY KEY CLUSTERED (ID)
END 
BEGIN 
    PRINT('Tabela TB_OnboardingAutomacoes_Segmentos já criada anteriormente.');
END 



IF(OBJECT_ID(RTRIM(LTRIM('FisicaContaEPS_FK_OnboardingAutomacoesEPS                '))) IS NULL) BEGIN  ALTER TABLE TB_Onboarding_Automacao_EPS    ADD CONSTRAINT FisicaContaEPS_FK_OnboardingAutomacoesEPS                 FOREIGN KEY (ID_EPS)          REFERENCES TB_FISICA_CONTA_EPS               (ID) END ELSE BEGIN PRINT('Constraint FisicaContaEPS_FK_OnboardingAutomacoesEPS                 já criada anteriormente') END 
IF(OBJECT_ID(RTRIM(LTRIM('OnboardingAutomacoes_FK_OnboardingAutomacoesEPS          '))) IS NULL) BEGIN  ALTER TABLE TB_Onboarding_Automacao_EPS    ADD CONSTRAINT OnboardingAutomacoes_FK_OnboardingAutomacoesEPS           FOREIGN KEY (ID_Automacao)    REFERENCES TB_Onboarding_Automacoes          (ID) END ELSE BEGIN PRINT('Constraint OnboardingAutomacoes_FK_OnboardingAutomacoesEPS           já criada anteriormente') END 
IF(OBJECT_ID(RTRIM(LTRIM('OnboardingSegmentosEnvio_FK_OnboardingAutomacaoEPS       '))) IS NULL) BEGIN  ALTER TABLE TB_Onboarding_Segmentos_Envio  ADD CONSTRAINT OnboardingSegmentosEnvio_FK_OnboardingAutomacaoEPS        FOREIGN KEY (ID_AutomacaoEPS) REFERENCES TB_Onboarding_Automacao_EPS       (ID) END ELSE BEGIN PRINT('Constraint OnboardingSegmentosEnvio_FK_OnboardingAutomacaoEPS        já criada anteriormente') END 
IF(OBJECT_ID(RTRIM(LTRIM('OnboardingSegmentosEnvio_FK_OnboardingAutomacoesSegmentos'))) IS NULL) BEGIN  ALTER TABLE TB_Onboarding_Segmentos_Envio  ADD CONSTRAINT OnboardingSegmentosEnvio_FK_OnboardingAutomacoesSegmentos FOREIGN KEY (ID_Segmento)     REFERENCES TB_OnboardingAutomacoes_Segmentos (ID) END ELSE BEGIN PRINT('Constraint OnboardingSegmentosEnvio_FK_OnboardingAutomacoesSegmentos já criada anteriormente') END 




INSERT INTO TB_OnboardingAutomacoes_Segmentos
(
     Segmento
    ,Cadastrado_Por
)

SELECT 
 Segmento
,Cadastrado_Por = 'Automatico'
FROM 
(
    SELECT Segmento = 'SEGMENTO 01', OrdemInsert = 1 UNION ALL
    SELECT Segmento = 'SEGMENTO 02', OrdemInsert = 2 UNION ALL
    SELECT Segmento = 'SEGMENTO 03', OrdemInsert = 3 UNION ALL
    SELECT Segmento = 'SEGMENTO 04', OrdemInsert = 4 UNION ALL
    SELECT Segmento = 'SEGMENTO 05', OrdemInsert = 5 UNION ALL
    SELECT Segmento = '', OrdemInsert = 0 
) AS Dados
WHERE 
       Segmento <> ''
   AND 0 = (SELECT COUNT(ID) FROM TB_OnboardingAutomacoes_Segmentos AS SUB WHERE SUB.Segmento = Dados.Segmento)
ORDER BY Dados.OrdemInsert
